package com.fdmgroup.aNewPokemartProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ANewPokemartProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
